// New Theme System - Two Themes Only
document.addEventListener('DOMContentLoaded', function() {
    // Get theme selector element
    const themeSelector = document.getElementById('themeSelector');
    if (!themeSelector) return;

    // Load saved theme from localStorage
    const savedTheme = localStorage.getItem('selectedTheme') || 'dark-professional';
    themeSelector.value = savedTheme;
    applyTheme(savedTheme);

    // Listen for theme changes
    themeSelector.addEventListener('change', function(e) {
        const selectedTheme = e.target.value;
        applyTheme(selectedTheme);
        localStorage.setItem('selectedTheme', selectedTheme);
        showThemeChangeNotification(selectedTheme);
    });
});

function applyTheme(theme) {
    document.body.style.transition = 'all 0.3s ease';

    // Apply selected theme
    document.body.setAttribute('data-theme', theme);

    // Store the theme preference
    localStorage.setItem('selectedTheme', theme);

    // Remove transition after it's complete
    setTimeout(() => {
        document.body.style.transition = '';
    }, 300);
}

function showThemeChangeNotification(theme) {
    const themeNames = {
        'dark-professional': 'الثيم الاحترافي الداكن',
        'original-light': 'الثيم الأصلي الفاتح'
    };

    // Show success toast
    if (typeof Swal !== 'undefined') {
        const Toast = Swal.mixin({
            toast: true,
            position: 'top-end',
            showConfirmButton: false,
            timer: 3000,
            timerProgressBar: true,
            didOpen: (toast) => {
                toast.addEventListener('mouseenter', Swal.stopTimer)
                toast.addEventListener('mouseleave', Swal.resumeTimer)
            }
        });

        Toast.fire({
            icon: 'success',
            title: `تم تطبيق ${themeNames[theme]} بنجاح`
        });
    }
}

// Generic alert dismissal
document.addEventListener('DOMContentLoaded', function() {
    // Auto-hide alerts after 5 seconds
    setTimeout(function() {
        const alerts = document.querySelectorAll('.alert');
        alerts.forEach(function(alert) {
            const dismissBtn = new bootstrap.Alert(alert);
            dismissBtn.close();
        });
    }, 5000);
});

// Form validation
document.addEventListener('DOMContentLoaded', function() {
    const forms = document.querySelectorAll('.needs-validation');

    Array.from(forms).forEach(function(form) {
        form.addEventListener('submit', function(event) {
            if (!form.checkValidity()) {
                event.preventDefault();
                event.stopPropagation();
            }
            form.classList.add('was-validated');
        }, false);
    });
});

// Initialize tooltips and popovers
document.addEventListener('DOMContentLoaded', function() {
    var tooltipTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="tooltip"]'));
    tooltipTriggerList.map(function(tooltipTriggerEl) {
        return new bootstrap.Tooltip(tooltipTriggerEl);
    });

    var popoverTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="popover"]'));
    popoverTriggerList.map(function(popoverTriggerEl) {
        return new bootstrap.Popover(popoverTriggerEl);
    });
});

// Responsive table handling
document.addEventListener('DOMContentLoaded', function() {
    const tables = document.querySelectorAll('.table-responsive table');
    tables.forEach(table => {
        if (table.offsetWidth > table.parentElement.offsetWidth) {
            table.parentElement.classList.add('table-scroll');
        }
    });
});

// Dynamic form fields
function addFormField(containerId, template) {
    const container = document.getElementById(containerId);
    const newRow = template.cloneNode(true);
    container.appendChild(newRow);
}

// Format currency in Egyptian Pounds
function formatCurrency(amount) {
    return new Intl.NumberFormat('ar-EG', {
        style: 'currency',
        currency: 'EGP'
    }).format(amount);
}

// Enhanced SweetAlert configurations
const SwalConfig = {
    success: {
        icon: 'success',
        background: 'var(--warm-white)',
        color: 'var(--dark-text)',
        confirmButtonColor: 'var(--primary)',
        showClass: {
            popup: 'animate__animated animate__fadeInDown'
        },
        hideClass: {
            popup: 'animate__animated animate__fadeOutUp'
        }
    },
    error: {
        icon: 'error',
        background: 'var(--warm-white)',
        color: 'var(--dark-text)',
        confirmButtonColor: 'var(--alert)',
        showClass: {
            popup: 'animate__animated animate__shakeX'
        }
    },
    warning: {
        icon: 'warning',
        background: 'var(--warm-white)',
        color: 'var(--dark-text)',
        confirmButtonColor: 'var(--alert)',
        cancelButtonColor: 'var(--neutral)'
    },
    info: {
        icon: 'info',
        background: 'var(--warm-white)',
        color: 'var(--dark-text)',
        confirmButtonColor: 'var(--primary)'
    }
};

// Enhanced SweetAlert functions
function showSuccessAlert(title, text = '') {
    return Swal.fire({
        title: title,
        text: text,
        ...SwalConfig.success
    });
}

function showErrorAlert(title, text = '') {
    return Swal.fire({
        title: title,
        text: text,
        ...SwalConfig.error
    });
}

function showConfirmAlert(title, text = '', confirmText = 'نعم', cancelText = 'إلغاء') {
    return Swal.fire({
        title: title,
        text: text,
        showCancelButton: true,
        confirmButtonText: confirmText,
        cancelButtonText: cancelText,
        ...SwalConfig.warning
    });
}

// Loading animation
function showLoadingAlert(title = 'جاري التحميل...') {
    return Swal.fire({
        title: title,
        allowOutsideClick: false,
        allowEscapeKey: false,
        showConfirmButton: false,
        background: 'var(--warm-white)',
        color: 'var(--dark-text)',
        didOpen: () => {
            Swal.showLoading();
        }
    });
}

// Function to toggle password visibility
function togglePasswordVisibility(inputId, iconId) {
    var passwordInput = document.getElementById(inputId);
    var icon = document.getElementById(iconId);

    if (passwordInput.type === 'password') {
        passwordInput.type = 'text';
        icon.classList.remove('fa-eye');
        icon.classList.add('fa-eye-slash');
    } else {
        passwordInput.type = 'password';
        icon.classList.remove('fa-eye-slash');
        icon.classList.add('fa-eye');
    }
}
